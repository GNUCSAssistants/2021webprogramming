const menus = ["짜장면", "짬뽕", "탕수육"];
let i = 0;
while (menus[i]) {
  console.log(menus[i]);
  i++;
}

