const menus = ["짜장면", "짬뽕", "탕수육"];
for (let i = 0; i < menus.length; i++) {
  console.log(menus[i]);
}
