const students = ["조교행님", "지연이", "혁주", "민지", "은혁"];

const newStudents = students.filter(student => student.length > 2);

console.log(newStudents);

