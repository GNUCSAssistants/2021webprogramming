const menus = ["짜장면", "짬뽕", "탕수육"];

const newMenus = menus.map(menu => `${menu} 좋아!`);

console.log(newMenus);