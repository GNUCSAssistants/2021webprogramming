const sampleFunction = () => {
  console.log("짜잔");
};

setTimeout(sampleFunction, 2000);
// setTimeout(sampleFunction = () => console.log("짜잔"), 2000);
// setTimeout(() => console.log("짜잔"), 2000);  // lambda