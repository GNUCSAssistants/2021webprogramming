const changeSquareColor = () => {
    document.querySelector(".square").style.backgroundColor = "red";
};