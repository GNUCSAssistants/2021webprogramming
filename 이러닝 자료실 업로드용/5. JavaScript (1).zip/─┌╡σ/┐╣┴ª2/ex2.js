const myFavorite = "아빠";

if (myFavorite === "엄마") {
  console.log("엄마가 좋아");
} else if (myFavorite === "아빠") {
  console.log("아빠가 좋아");
} else if (myFavorite === "누나") {
  console.log("누나가 좋아");
} else {
  console.log("다 싫어");
}

const age = 20;

if (age >= 20) {
  console.log("술 판매 가능");
} else {
  console.log("영업정지 삐용삐용");
}

// const myName = ""
const myName = "조교행님"

if (myName) {
  console.log("안녕");
} else {
  console.log("이름이 뭐야?");
}