setTimeout(() => {
  window.location.href = "../html/myorder.html";
}, 3000);
