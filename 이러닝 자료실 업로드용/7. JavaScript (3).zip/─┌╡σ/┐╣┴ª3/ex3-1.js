const myCal = {
  add: (a, b) => a + b,
  subtract: (a, b) => a - b,
  multiply: (a, b) => a * b,
  devide: (a, b) => a / b,
};

console.log(myCal.add(5, 2)); // 7
console.log(myCal.subtract(5, 2)); // 3
console.log(myCal.multiply(5, 2)); // 10
console.log(myCal.devide(5, 2)); // 2.5
