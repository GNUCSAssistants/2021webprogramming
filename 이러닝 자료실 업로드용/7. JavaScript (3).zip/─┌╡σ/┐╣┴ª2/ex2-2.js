const c = 5;

const showResult = () => console.log(c);

showResult();
