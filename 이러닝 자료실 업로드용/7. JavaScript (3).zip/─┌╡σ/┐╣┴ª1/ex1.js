// function sayHello(name, age) {
//     return `안녕, ${name}. 나이는 ${age}세`;
// }

const sayHello = (name, age) => `안녕, ${name}. 나이는 ${age}세`;

console.log(sayHello("조교행님", 28));
console.log(sayHello("은지", 16));
console.log(sayHello("현수", 21));
console.log(sayHello("지원", 14));
console.log(sayHello("준수", 23));
