const a = [1, 2, 3];
const b = [1, 2, 3];

if (a === b) {
    console.log("같다");
} else {
    console.log("다르다");
}

const c = {
    myName: "조교행님",
    age: 28
}
const d = {
    myName: "조교행님",
    age: 28
}

if (c === d) {
    console.log("같다");
} else {
    console.log("다르다");
}
