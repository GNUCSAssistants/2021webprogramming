const a = {};  // 또는 []
if(a) {
    console.log(true);
} else {
    console.log(false);
}