const daysOfWeek = ["월", "화", "수", "목", "금", "토", "일"];

console.log(daysOfWeek[0]); // 월
console.log(daysOfWeek[1]); // 화
console.log(daysOfWeek[6]); // 일
console.log(daysOfWeek[7]); // undefined

