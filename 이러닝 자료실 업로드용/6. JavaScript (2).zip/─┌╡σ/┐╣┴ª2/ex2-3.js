const matrix = ["김치찌개", "햄버거", ["짜장면", "짬뽕", "탕수육"]];

console.log(matrix[2][1]);  // 짬뽕